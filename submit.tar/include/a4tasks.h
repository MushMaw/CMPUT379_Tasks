/**
 * CMPUT 379 - Assignment 4
 * File Name: a4tasks.h
 * Student Name: Jacob Bakker
 *
 * Implements a basic main function for "a4tasks" program that simply
 * starts and runs a Session using command line input.
 */

#if !defined(A4_TASKS_H)
#define A4_TASKS_H 1

#include "SessionClass.h"

#endif
